package save_money.Offers;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.intern.R;

public class Patholgy_LaborartoryOffers extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patholgy__laborartory_offers);
    }
}
