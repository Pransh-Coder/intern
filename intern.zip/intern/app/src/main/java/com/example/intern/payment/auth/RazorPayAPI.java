package com.example.intern.payment.auth;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;

public interface RazorPayAPI {
	@GET("payments/{paymentID}")
	Call<PaymentEntity> paymentInfo(@Path("paymentID") String paymentID);
}
