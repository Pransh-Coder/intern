package com.example.intern;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Gifts extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_screen_12);
        getSupportActionBar().hide();
    }
}
